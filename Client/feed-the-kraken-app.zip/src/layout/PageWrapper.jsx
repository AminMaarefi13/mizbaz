import React from "react";

const PageWrapper = () => {
  return <></>;
};

export default PageWrapper;
