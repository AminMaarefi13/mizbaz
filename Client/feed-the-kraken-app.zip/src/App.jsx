// src/App.jsx
import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import AppLayout from "./layout/AppLayout";

// Page imports
import HomePage from "./pages/HomePage";
import MapPage from "./pages/MapPage";
import PlayersPage from "./pages/PlayersPage";
import SettingsPage from "./pages/SettingsPage";

// Main App component with routing and layout
function App() {
  return (
    <Router>
      <Routes>
        {/* Default layout with chat */}
        <Route
          path="/"
          element={
            <AppLayout showChat={true}>
              <HomePage />
            </AppLayout>
          }
        />
        <Route
          path="/map"
          element={
            <AppLayout showChat={false}>
              <MapPage />
            </AppLayout>
          }
        />
        <Route
          path="/players"
          element={
            <AppLayout showChat={false}>
              <PlayersPage />
            </AppLayout>
          }
        />
        <Route
          path="/settings"
          element={
            <AppLayout showChat={false}>
              <SettingsPage />
            </AppLayout>
          }
        />
      </Routes>
    </Router>
  );
}

export default App;
