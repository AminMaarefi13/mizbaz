import React from "react";

const GameContext = () => {
  return <></>;
};

export default GameContext;
