// src/pages/SettingsPage.jsx
import React from "react";

const SettingsPage = () => {
  return (
    <div className="p-4">
      <h2 className="text-lg font-bold">Settings</h2>
      <p className="text-gray-500">More options coming soon...</p>
    </div>
  );
};

export default SettingsPage;
