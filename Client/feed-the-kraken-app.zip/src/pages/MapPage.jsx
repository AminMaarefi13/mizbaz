// src/pages/MapPage.jsx
import React from "react";
import MapView from "../components/Map/MapView";

const MapPage = () => {
  return (
    <div className="p-4">
      <MapView />
    </div>
  );
};

export default MapPage;
