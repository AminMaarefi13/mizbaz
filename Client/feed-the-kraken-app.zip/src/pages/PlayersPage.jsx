import React, { useState, useEffect } from "react";
import PlayerList from "../components/Players/PlayerList";

const PlayersPage = () => {
  // اینجا می‌توانید وضعیت بازیکن‌ها را از context یا سرور دریافت کنید.
  const [isPirate, setIsPirate] = useState(false);
  const [isCabinetMember, setIsCabinetMember] = useState(false);

  useEffect(() => {
    // وضعیت‌های pirate و cabinetMember رو بر اساس اطلاعاتی که دریافت می‌کنید ست کنید
    setIsPirate(true); // یا false
    // setIsCabinetMember(true); // یا false
  }, []);

  return (
    <div className="p-4">
      <h2 className="text-lg font-bold mb-2">Players</h2>
      <PlayerList isPirate={isPirate} isCabinetMember={isCabinetMember} />
    </div>
  );
};

export default PlayersPage;
