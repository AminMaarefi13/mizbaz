// src/pages/HomePage.jsx
import React, { useState } from "react";
import ShipStatusBar from "../components/GameStatus/ShipStatusBar";
import CrewRolesDisplay from "../components/GameStatus/CrewRolesDisplay";
import PhaseIndicator from "../components/GameStatus/PhaseIndicator";
import CabinetUI from "../components/GameStatus/CabinetUI";

const HomePage = () => {
  // 🔹 فرض: بازیکن حاضر ناخدا است (برای تست)
  const isCaptain = false;
  //   const isCaptain = true;

  // 🔹 لیست بازیکنان نمونه برای تست (واقعاً باید از سرور یا context بیاد)
  const [players] = useState([
    { id: "1", name: "Ali" },
    { id: "2", name: "Sara" },
    { id: "3", name: "Reza" },
    { id: "4", name: "Niloofar" },
  ]);

  // 🔹 وقتی ناخدا کابینه را تأیید کرد
  const onConfirmCabinet = (cabinet) => {
    console.log("✅ کابینه تأیید شد:", cabinet);
    // اینجا می‌تونی کابینه رو به سرور بفرستی یا وارد state بازی کنی
  };

  return (
    <div className="space-y-4">
      <ShipStatusBar />
      <PhaseIndicator />
      {/* <CrewRolesDisplay /> */}
      <CabinetUI
        isCaptain={isCaptain}
        players={players}
        onConfirmCabinet={onConfirmCabinet}
      />
    </div>
  );
};

export default HomePage;
